package join;

public class JoinApplication {
   public static void main(String[] args) throws Exception {
  	 JoinController controller = new JoinController();
 		 controller.getJoins();
	}
}
