package sign;

public class SignApplication {
   public static void main(String[] args) throws Exception {
  	 SignController controller = new SignController();
 		 controller.getSigns();
	}
}
